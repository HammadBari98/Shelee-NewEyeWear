<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
      <title>Shelee's Spectacle</title>
    <meta name="description" content="Admin, Dashboard, Bootstrap, Bootstrap 4, Angular, AngularJS" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- for ios 7 style, multi-resolution icon of 152x152 -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-barstyle" content="black-translucent">
    <!-- <link rel="apple-touch-icon" href="http://starholidaysgroup.com/beta/backEnd/assets/images/logo.png"> -->
    <meta name="apple-mobile-web-app-title" content="Flatkit">
    <!-- for Chrome on Android, multi-resolution icon of 196x196 -->
    <meta name="mobile-web-app-capable" content="yes">
    <!-- <link rel="shortcut icon" sizes="196x196" href="http://starholidaysgroup.com/beta/backEnd/assets/images/logo.png"> -->

  <!--   style -->
    <link rel="stylesheet" href="backEnd/assets/animate.css/animate.min.css" type="text/css" />
    <link rel="stylesheet" href="backEnd/assets/glyphicons/glyphicons.css" type="text/css" />
    <link rel="stylesheet" href="backEnd/assets/font-awesome/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="backEnd/assets/material-design-icons/material-design-icons.css" type="text/css" />

    <link rel="stylesheet" href="bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="app.min.css" type="text/css">
    <!-- <link rel="stylesheet" href="http://starholidaysgroup.com/beta/backEnd/assets/styles/font.css" type="text/css" /> -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">

    <!-- Font Awesome Cdn -->
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<style>

</style>
<body>

    <div class="app" id="app">
     <?php 
        include('nav.php');
         
     
     ?>
            <div ui-view class="app-body" id="view">

                <!-- ############ PAGE START-->
                <div class="padding">
                    <div class="box">
                        <div class="box-header dker leftHead">

                            <h3>Manage Customers</h3>
                           </div>


                   




                        <!--   <nav class="scroll nav-active-primary dd_navi">
                    <ul class="nav" ui-nav> -->
                        <!--   <li class="active_green">
                            <a class="nav-link" href="http://starholidaysgroup.com/beta/admin/supplier_hotels/create">
                                <i class="material-icons">&#xe02e;</i>
                                &nbsp; Add New Supplier</a>
                        </li>  -->
                        <!-- Sami Code -->


                        <!-- Sami Code -->




                        <!-- <li>
                        	<a>
                                <span class="nav-caret">
                                    <i class="fa fa-caret-down"></i>
                                </span>
                                <span class="nav-icon">
                                	<i class="material-icons">&#xe5c3;</i>
                                </span>
                                <span class="nav-text">Hotel Management</span>
                            </a>
                            <ul class="nav-sub">    
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/hotels/create">
                                        <span class="nav-text">Add New</span>
                                    </a>
                                </li> 
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/hotels">
                                        <span class="nav-text">Manage Hotels</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/hotel-facilities">
                                        <span class="nav-text">Hotel Facilities</span>
                                    </a>
                                </li> 
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/hotel-types">
                                        <span class="nav-text">Hotel Types</span>
                                    </a>
                                </li>                              
                            </ul>
                        </li> 
                        <li>
                        	<a>
                                <span class="nav-caret">
                                    <i class="fa fa-caret-down"></i>
                                </span>
                                <span class="nav-icon">
                                	<i class="material-icons">&#xe5c3;</i>
                                </span>
                                <span class="nav-text">Rooms Management</span>
                            </a>
                            <ul class="nav-sub">    
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/rooms/create">
                                        <span class="nav-text">Add New</span>
                                    </a>
                                </li> 
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/rooms">
                                        <span class="nav-text">Manage Rooms</span>
                                    </a>
                                </li>          
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/room-types">
                                        <span class="nav-text">Room Types</span>
                                    </a>
                                </li>  
                                <li>
                                    <a href="http://starholidaysgroup.com/beta/admin/room-amenities">
                                        <span class="nav-text">Room Amenities</span>
                                    </a>
                                </li>                   
                            </ul>
                        </li> -->

                        <!--   </ul>
                </nav> -->
                        <!-- </div> -->


                        <form method="POST" accept-charset="UTF-8"><input name="_token" type="hidden" value="I0KGyVt2VAOnERrELpYVner9aWG0gr71QyqGezif">

                            <div class="table-responsive">

                                <table class="table table-striped  b-t">
                                    <thead>
                                        <tr>
                                            <th class="width5">
                                                <label class="ui-check m-a-0">
                                                    <input id="checkAll" type="checkbox"><i></i>
                                                </label>
                                            </th>
                                            <th>Client Name</th>
                                            <th>Client Email</th>
                                            
                                            <th>Cell Number</th>
                                            <th>Details</th>

                                            <th>Delete</th>

                                            <!-- <th class="text-center" style="width:200px;">Options</th> -->
                                        </tr>

                                    </thead>
                                    <tbody>
                                    
                                            <tr>

                                                <td></td>

                                                <td>
                                                    Bilal
                                                </td>
                                                <td>
                                        bilal@admin.com     
                                            </td>
                                               

                                                <td>
                                                    <!-- <?php echo $row['Mobile']  ?> -->
                                                    033122445566
                                                </td>

                                                <td>
                                                <ul class="nav" ui-nav>

<li class="active_green">
    <!-- Button trigger modal -->
    <a href="CusDetail.php" type="button" class="btn btn-sm primary">

        Details

    </a>
    

</li>

<!-- Modal -->


<!--  <li class="active_green">

    <button type="button" class="btn btn-sm primary" id="btnNew" data-toggle="modal" data-target="#mmn-import" ui-toggle-class="bounce" ui-target="#animate">

        backLang.supplierImport

    </button>

</li>  -->

</ul>
                                                    
                                                </td>
                                                <td>
                                                <ul class="nav" ui-nav>

<li class="active_green">
    <!-- Button trigger modal -->
    
    <a href="#" type="button" class="btn btn-sm primary">

Delete

</a>

</li>

<!-- Modal -->


<!--  <li class="active_green">

    <button type="button" class="btn btn-sm primary" id="btnNew" data-toggle="modal" data-target="#mmn-import" ui-toggle-class="bounce" ui-target="#animate">

        backLang.supplierImport

    </button>

</li>  -->

</ul>
                                                    
                                                </td>
                                              
                                                <!-- <td class="text-center">
            <i class="fa fa-times text-danger
                                    inline"></i>
                            </td> -->
                                                <td class="text-center">

                                                    <!-- <a class="btn btn-sm success" href="http://starholidaysgroup.com/beta/admin/customers/agents/1/view"> -->
                                                    <!-- <small><i class="material-icons">&#xe3c9;</i> Details </small> -->
                                                    <!-- </a> -->
                                                </td>
                                            
                                            </tr>
                                            <!-- .modal -->
                                            <div id="m-1" class="modal fade" data-backdrop="true">
                                                <div class="modal-dialog" id="animate">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Confirmation</h5>
                                                        </div>
                                                        <div class="modal-body text-center p-lg">
                                                            <p>
                                                                Are you sure you want to delete?
                                                                <br>
                                                                <strong>[ ]</strong>
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn dark-white p-x-md" data-dismiss="modal">Sr #</button>
                                                            <a href="#" class="btn danger p-x-md">Yes</a>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                            </div>
                                            <!-- / .modal -->
                                            <tr>


                                                <!-- <td class="text-center">
            <i class="fa fa-times text-danger
                                    inline"></i>
                            </td> -->

                                            </tr>
                                            <!-- .modal -->
                                            <div id="m-3" class="modal fade" data-backdrop="true">
                                                <div class="modal-dialog" id="animate">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Confirmation</h5>
                                                        </div>
                                                        <div class="modal-body text-center p-lg">
                                                            <p>
                                                                Are you sure you want to delete?
                                                                <br>
                                                                <strong>[ ]</strong>
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn dark-white p-x-md" data-dismiss="modal">Sr #</button>
                                                            <a href="#" class="btn danger p-x-md">Yes</a>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                            </div>
                                            <!-- / .modal -->

                                    </tbody>
                                </table>

                            </div>
                            <script type="text/javascript">
                                $("#checkAll").click(function() {
                                    $('input:checkbox').not(this).prop('checked', this.checked);
                                });
                                $("#action").change(function() {
                                    if (this.value == "delete") {
                                        $("#submit_all").css("display", "none");
                                        $("#submit_show_msg").css("display", "inline-block");
                                    } else {
                                        $("#submit_all").css("display", "inline-block");
                                        $("#submit_show_msg").css("display", "none");
                                    }
                                });
                            </script>

                    </div>
                </div>
                <!-- ############ PAGE END-->

            </div>
        </div>
        <!-- / -->

        <!-- theme switcher -->
        <div id="switcher">
            <div class="switcher box-color dark-white text-color" id="sw-theme">
                <a href ui-toggle-class="active" target="#sw-theme" class="box-color dark-white text-color sw-btn">
                    <i class="fa fa-gear"></i>
                </a>
                <div class="box-header">
                    <h2>Theme Switcher</h2>
                </div>
                <div class="box-divider"></div>
                <div class="box-body">
                    <p class="hidden-md-down">
                        <label class="md-check m-y-xs" data-target="folded">
                            <input type="checkbox">
                            <i class="green"></i>
                            <span class="hidden-folded">Folded Aside</span>
                        </label>
                        <label class="md-check m-y-xs" data-target="boxed">
                            <input type="checkbox">
                            <i class="green"></i>
                            <span class="hidden-folded">Boxed Layout</span>
                        </label>
                    </p>


                    <p>Themes:</p>
                    <div data-target="bg" class="text-u-c text-center _600 clearfix">
                        <label class="p-a col-xs-6 light pointer m-a-0">
                            <input type="radio" name="theme" value="" hidden>
                            LIGHT
                        </label>
                        <label class="p-a col-xs-6 grey pointer m-a-0">
                            <input type="radio" name="theme" value="grey" hidden>
                            GREY
                        </label>
                        <label class="p-a col-xs-6 dark pointer m-a-0">
                            <input type="radio" name="theme" value="dark" hidden>
                            Dark
                        </label>
                        <label class="p-a col-xs-6 black pointer m-a-0">
                            <input type="radio" name="theme" value="black" hidden>
                            Black
                        </label>
                    </div>
                    <br>

                    <p>Language:</p>

                    <form method="POST" action="http://starholidaysgroup.com/beta/lang" accept-charset="UTF-8"><input name="_token" type="hidden" value="I0KGyVt2VAOnERrELpYVner9aWG0gr71QyqGezif">

                        <div class="form-group">
                            <select name="locale" id="locale" class="form-control c-select">
                                <option value="en" selected=&#039;selected&#039;>[ English ]</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-success btn-sm" type="submit" value="Change">
                        </div>
                    </form>
                    <a href="#" onclick="return confirm('Are you sure to clear cache &amp; temp files?')"><small>Clear cache & temp files?</small></a>
                </div>
            </div>

        </div>
        <!-- / -->

        <!-- ############ LAYOUT END-->

    </div>


    <script type="text/javascript">
        var public_lang = "en"; // this is a public var used in app.html.js to define path to js files
        var public_folder_path = "http://starholidaysgroup.com/beta"; // this is a public var used in app.html.js to define path to js files
    </script>
    <script src="backEnd/scripts/app.html.js"></script>


    <script type="text/javascript">
        $("#checkAll").click(function() {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
        $("#action").change(function() {
            if (this.value == "delete") {
                $("#submit_all").css("display", "none");
                $("#submit_show_msg").css("display", "inline-block");
            } else {
                $("#submit_all").css("display", "inline-block");
                $("#submit_show_msg").css("display", "none");
            }
        });
    </script>

</body>

</html>
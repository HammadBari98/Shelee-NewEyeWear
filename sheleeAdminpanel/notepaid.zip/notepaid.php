Product Management

   1. Category                e  
      Catagory Name 
      Catagory Image
 
   2. Add Sub Category
     Sub Catagory Name
     Select Catagory
     Sub Catagory Image

   3. Service                 e  
     Select Catagory 
     Select Sub Catagory 
     Product Name
     Price 
     Company Name / Brand Name  
     Discription
     Product Image
   
2. Booking Detail
   Customer Name,
   Shipping Address,
   Products detail
   Price 
   Quantity
   phone Number
   Booking Date
   left eye 
   right eye
   Complete (status option)

   2 option 1 is pending and other is complete

3. Discount
   Sub catagory 
   Discount ____%

4.